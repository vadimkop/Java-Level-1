import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random rand = new Random();
        do {
            int correctanswer = rand.nextInt(10);
            System.out.println("Guess the number. You have three tries");
            for (int i = 3; i > 0; i--) {
                System.out.println("Your answer: ");
                int answer = scanner.nextInt();
                if (answer == correctanswer) {
                    System.out.println("Win!");
                    break;
                }
                if (answer > correctanswer) System.out.println("Wrong! Your number is more");
                if (answer < correctanswer) System.out.println("Wrong! Your number is less");
            }
            System.out.println("Again? 1 - yes or 2 - no");
        }
        while (scanner.nextInt() == 1);
    }
}


